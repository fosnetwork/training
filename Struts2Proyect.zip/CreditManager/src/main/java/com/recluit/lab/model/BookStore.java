package com.recluit.lab.model;

import java.util.ArrayList;
import java.util.List;

public class BookStore {
	private List<Book> allBooks;

	public BookStore() {
		allBooks = new ArrayList<Book>();
		allBooks.add(new Book("Sherlock Holmes", "Arthur Conan Doyle"));
		allBooks.add(new Book("Le parfum", "Patrick Suskind"));
	}

	public List<Book> getAllBooks() {
		return allBooks;
	}

	public void setAllBooks(List<Book> allBooks) {
		this.allBooks = allBooks;
	}

}
