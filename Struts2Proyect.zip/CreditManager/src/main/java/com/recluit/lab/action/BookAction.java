package com.recluit.lab.action;

import com.opensymphony.xwork2.ActionSupport;
import com.recluit.lab.model.Book;
import com.recluit.lab.model.BookStore;

public class BookAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	public BookStore getBookStore() {
		return bookStore;
	}

	public void setBookStore(BookStore bookStore) {
		this.bookStore = bookStore;
	}

	public String getBookQuery() {
		return bookQuery;
	}

	public void setBookQuery(String bookQuery) {
		this.bookQuery = bookQuery;
	}

	public String getBookResulTitle() {
		return bookResulTitle;
	}

	public void setBookResulTitle(String bookResulTitle) {
		this.bookResulTitle = bookResulTitle;
	}

	public String getBookResultAuthor() {
		return bookResultAuthor;
	}

	public void setBookResultAuthor(String bookResultAuthor) {
		this.bookResultAuthor = bookResultAuthor;
	}

	private BookStore bookStore;
	private String bookQuery;
	private String bookResulTitle;
	private String bookResultAuthor;

	public String execute() throws Exception {
		bookStore = new BookStore();
		for (Book book : bookStore.getAllBooks()) {
			if (book.getTitle().equals(bookQuery)) {
				bookResulTitle = book.getTitle();
				bookResultAuthor = book.getAuthor();
				return SUCCESS;
			}
		}
		return ERROR;
	}
}