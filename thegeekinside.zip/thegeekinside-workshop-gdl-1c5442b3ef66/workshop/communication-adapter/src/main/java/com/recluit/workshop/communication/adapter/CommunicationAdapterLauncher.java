package com.recluit.workshop.communication.adapter;

/**
 * Hello world!
 *
 */
public class CommunicationAdapterLauncher
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
