package Updates;
import java.io.*;

public class ToSocket implements Serializable{
	private static final long serialVersionUID = 1L;

		   public ToSocket (String cadena)
	   {
	      if (cadena != null)
	      {
	         c = cadena.length();
	         d = cadena;
	      }
	   }

	   
	   public int c = 0;
	     
	   public String d = "";
	     
	   public String toString ()
	   {
	     String resultado;
	          
	     resultado = Integer.toString(c) + "--> " + d;
	      return resultado;
	   }

	   public void writeObject(DataOutputStream out)
	         throws IOException
	     {
	       
	         out.writeInt (c+1);

	        
	         out.writeBytes (d);

	     }
	    
	     public void readObject(DataInputStream in)
	     throws IOException
	    {
	         c = in.readInt() - 1;
	         	         
	    byte [] aux = null;
	         
	     aux = new byte[c];   
	     in.read(aux, 0, c);   
	      d = new String (aux);
	      in.read(aux,0,1);    
	     }

}
