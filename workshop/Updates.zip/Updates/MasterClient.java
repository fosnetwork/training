package Updates;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class MasterClient {

	@SuppressWarnings("resource")
	public void establishConnection() {
		try {
			Socket s = new Socket("0.0.0.0", 3550);
			InputStreamReader stream = new InputStreamReader(s.getInputStream());
			BufferedReader reader = new BufferedReader(stream);
			String str = reader.readLine();
			System.out.println(" text received from client ;" + str);
			ToSocket dato = new ToSocket("El Mero Mero Sabor Ranchero");
			DataOutputStream bufferSalida = new DataOutputStream(
					s.getOutputStream());
			dato.writeObject(bufferSalida);
			System.out.println("Servidor Java: Enviado " + dato.toString());

			DataInputStream bufferEntrada = new DataInputStream(
					s.getInputStream());
			ToSocket aux = new ToSocket("");
			aux.readObject(bufferEntrada);
			System.out.println("Servidor java: Recibido " + aux.toString());

			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new MasterClient().establishConnection();
	}
}