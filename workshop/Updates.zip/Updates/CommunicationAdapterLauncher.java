package Updates;


/**
 * Hello world!
 *
 */
public class CommunicationAdapterLauncher
{
    public static void main( String[] args )
    {
        SocketConnection con = new SocketConnection();
        try {
            con.connect();
            con.sendData("FOSNETWORK\n");
            con.receiveData();
//            con.close();
//            con.connect();
//            con.sendData("S3002001234564777538801\n");
//            con.receiveData();
//            con.close();
//            con.connect();
//            con.sendData("S3002001234564777538801\n");
//            con.receiveData();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
