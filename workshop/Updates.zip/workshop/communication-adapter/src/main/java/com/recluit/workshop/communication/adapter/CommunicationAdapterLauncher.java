package com.recluit.workshop.communication.adapter;

import java.io.IOException;

/**
 * Hello world!
 *
 */
public class CommunicationAdapterLauncher
{
    public void clienSocket
    {
        try {
            SocketConnection con = new SocketConnection("0.0.0.0", 3550, 10000);
            con.connect();
            con.addListener(new MessageListener());
            StringBuilder b = new StringBuilder();

            b.append("RELM");
            b.append("23456ABCDE");
            b.append("otro");
            con.sendData(b.toString());

            con.receiveData();
            con.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

public static void main(String[] args )
{
	CommunicationAdapterLauncher conector = new CommunicationAdapterLauncher();
	conector.clientSocket ();
	
}
}