
public class RunTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("this is the main");
	}
}
